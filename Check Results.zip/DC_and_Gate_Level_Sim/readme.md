1. DC
(1)run 'design_vision &'
(2)type 'source run.tcl'
The report of timing, area, power are saved in '/rpt'
The netlist is saved in '/write/netlist.v'
2. Gate Level Simulation
run './Gate_Level_Simulation'

3. RTL Simulation
run './rtl_sim'

The result of RTL Simulation and Gate Level Simulation will be saved in numError.txt

